import React from 'react';
import { useSetState } from 'react-use';

export const AuthenticateContext = React.createContext(null);

const initialState = {
  isUserLoggedIn: false,
  isLoginLoading: false,
  loginError: null
}

export const ContextProvider = props => {
  const [state, setState] = useSetState(initialState);

  const setLoginLoading = (isLoginLoading) => setState({isLoginLoading});
  const setLoginSuccess = (isUserLoggedIn) => setState({isUserLoggedIn});
  const setLoginError = (loginError) => setState({loginError});

  const login = (email, password) => {
    setLoginLoading(true);
    setLoginSuccess(false);
    setLoginError(null);

    fetchLogin( email, password, error => {
      setLoginLoading(false);

      if (!error) {
        setLoginSuccess(true);
      } else {
        setLoginError(error);
      }
    })
  }

  const logout = () => {
    setLoginLoading(false);
    setLoginSuccess(false);
    setLoginError(null);
  }

  return (
    <AuthenticateContext.Provider
      value={{
        state,
        login,
        logout,
      }}
    >
      {props.children}
    </AuthenticateContext.Provider>
  );
};

// fake login credential
const fetchLogin = (email, password, callback) => 
  setTimeout(() => {
    if (email === 'user123' && password === 'Test@123') {
      return callback(null);
    } else {
      return callback(new Error('Invalid email and password'));
    }
  }, 1000);